package com.example.examen.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.examen.R;
import com.example.examen.controller.Controller;

public class ResultActivity extends AppCompatActivity {
    private TextView txtview;
    private Button retour;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        init();
        Intent intent =getIntent();
        if (intent !=null){
            long secondstoconvert=intent.getLongExtra("SECONDSTOCONVERT",0);
            Controller controller =Controller.getInstance();
            controller.createTimeConversion((int) secondstoconvert);
            String formattedTime=controller.getTemps();
            txtview.setText(formattedTime);
        }

    }
    public void init(){
        txtview.findViewById(R.id.txtresult);
        retour =findViewById(R.id.retour);
        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent (ResultActivity.this,MainActivity.class);
                startActivityForResult(intent,1);
            }
        });

    }
}