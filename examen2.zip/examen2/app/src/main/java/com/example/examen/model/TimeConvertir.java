package com.example.examen.model;

public class TimeConvertir {
    private int seconds;

    public TimeConvertir(int s){

        this.seconds=s;
    }



    public int getSeconds() {
        return seconds;
    }

    public void setSeconds(int seconds) {
        this.seconds = seconds;
    }
}
